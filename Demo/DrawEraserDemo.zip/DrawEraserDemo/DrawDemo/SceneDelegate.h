//
//  SceneDelegate.h
//  DrawDemo
//
//  Created by TsanFeng Lam on 2020/3/24.
//  Copyright © 2020 lfsampleprojects. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

